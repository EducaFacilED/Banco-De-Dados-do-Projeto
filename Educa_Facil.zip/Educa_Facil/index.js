const express = require('express');
const app = express();
const bodyparser = require('body-parser');
const Usuario = require('./models/Usuario');
const connection = require('./models/database');

connection 
    .authenticate ()
    .then (() => {
        console.log('Conexão feita com sucesso!');
    })
    .catch((msgErrror) => {
        console.log(msgErrror);
    })

    app.listen (8080, () => {
        console.log('Rodando.')
    })