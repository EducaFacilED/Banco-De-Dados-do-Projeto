const Sequelize = require('sequelize')
const connection = new Sequelize('EducaFacil', 'root', 'escola', {
    host: 'localhost',
    dialect: 'mysql',
    logging: false
});

module.exports = connection;