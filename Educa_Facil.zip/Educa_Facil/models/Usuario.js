const sequelize = require('sequelize')
const connection = require('./database')
const Usuario = connection.define('usuario', {
    id: {
        type: sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false
    },
    nome: {
        type: sequelize.STRING,
        allowNull: false
    },
    email: {
        type: sequelize.STRING,
        allowNull: false,
        unique: true
    },
    senha: {
        type: sequelize.STRING,
        allowNull: false
    },
    tipo: {
        type: sequelize.ENUM('aluno', 'professor', 'admin'),
        allowNull: false
    },
    fotoPerfil: {
        type: sequelize.STRING, 
        allowNull: true
    },
    dataCriacao: {
        type: sequelize.DATE,
        defaultValue: sequelize.NOW
    },
    nivel: {
        type: sequelize.INTEGER,
        defaultValue: 1 
    },
    experiencia: {
        type: sequelize.INTEGER,
        defaultValue: 0 
    },
    energia: {
        type: sequelize.INTEGER,
        defaultValue: 20
    },
    premium: {
        type: sequelize.BOOLEAN,
        defaultValue: false 
    },
    preferencias: {
        type: sequelize.JSON, 
        allowNull: true
    },
    historicoAtividades: {
        type: sequelize.JSON, 
        allowNull: true
    },
    progresso: {
        type: sequelize.JSON, 
        allowNull: true
    }

});


Usuario.sync({force: false}).then(() => {console.log("Tabela criada")})
module.exports = Usuario;